#!/bin/bash
cd /HNApp
./start.sh K1160PRO &
