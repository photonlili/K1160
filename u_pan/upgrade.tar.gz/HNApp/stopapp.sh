# !/bin/sh
cd /HNApp
./stop.sh k1160 &
