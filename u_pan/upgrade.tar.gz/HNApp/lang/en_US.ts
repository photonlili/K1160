<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>HNApp</name>
    <message>
        <location filename="../../../k1160/hnapp.cpp" line="115"/>
        <source>Some app want to run in u disk!accepted?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNCheckBox</name>
    <message>
        <location filename="../../../k1160/HnGui/hncheckbox.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNDialog</name>
    <message>
        <location filename="../../../k1160/HnGui/hndialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNListView</name>
    <message>
        <location filename="../../../k1160/HnGui/hnlistview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNLoginForm</name>
    <message>
        <location filename="../../../k1160/hnloginform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnloginform.ui" line="125"/>
        <source>Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnloginform.ui" line="215"/>
        <source>Enter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNMPTableWidget</name>
    <message>
        <location filename="../../../k1160/HnGui/hnmptablewidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HnGui/hnmptablewidget.ui" line="57"/>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HnGui/hnmptablewidget.ui" line="64"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HnGui/hnmptablewidget.ui" line="71"/>
        <source>&lt;&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HnGui/hnmptablewidget.ui" line="78"/>
        <source>&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HnGui/hnmptablewidget.ui" line="88"/>
        <source>-&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNMainForm</name>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="140"/>
        <source>Automatic Kjeldahl Apparatus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="285"/>
        <source>XX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="292"/>
        <source>Logined</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="333"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="359"/>
        <location filename="../../../k1160/hnmainform.ui" line="634"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="381"/>
        <source>AutoTest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="403"/>
        <source>ManuTest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="425"/>
        <source>Clean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="451"/>
        <location filename="../../../k1160/hnmainform.ui" line="473"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="499"/>
        <source>Set up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="524"/>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="546"/>
        <source>Machine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="568"/>
        <source>CleanSet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="590"/>
        <source>Calibrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="612"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="656"/>
        <source>SetUser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="678"/>
        <source>Suyuan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="704"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="726"/>
        <location filename="../../../k1160/hnmainform.ui" line="847"/>
        <source>Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="748"/>
        <source>Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="774"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="796"/>
        <source>Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmainform.ui" line="822"/>
        <source>Cloud</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNManageEthenetWidget</name>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.ui" line="47"/>
        <source>Select network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.ui" line="54"/>
        <source>IP configure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.ui" line="61"/>
        <source>Current:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.ui" line="71"/>
        <source>Use DHCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.ui" line="81"/>
        <source>Ip address:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.ui" line="91"/>
        <source>Mask:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.ui" line="114"/>
        <source>Gateway:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.ui" line="140"/>
        <source>DNS:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.ui" line="150"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.cpp" line="40"/>
        <source>Current:Wired Lan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageethenetwidget.cpp" line="45"/>
        <source>Current:%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNManageUserWidget</name>
    <message>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="32"/>
        <source>User Manager:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="42"/>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="96"/>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="103"/>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="127"/>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="134"/>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="148"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="49"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="82"/>
        <source>Creater:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="89"/>
        <source>Authority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="110"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="117"/>
        <source>Comment:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="141"/>
        <source>CreateTime:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="174"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmanageuserwidget.ui" line="181"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNMsgBox</name>
    <message>
        <location filename="../../../k1160/hnmsgbox.ui" line="43"/>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmsgbox.ui" line="63"/>
        <location filename="../../../k1160/hnmsgbox.ui" line="100"/>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnmsgbox.ui" line="131"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNPasswordDialog</name>
    <message>
        <location filename="../../../k1160/hnpassworddialog.ui" line="14"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnpassworddialog.ui" line="26"/>
        <source>WIFI:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnpassworddialog.ui" line="49"/>
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnpassworddialog.ui" line="62"/>
        <source>SSID NAME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnpassworddialog.ui" line="75"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNPreviewWidget</name>
    <message>
        <location filename="../../../k1160/HnGui/HNPreviewWidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HnGui/HNPreviewWidget.ui" line="20"/>
        <source>Hanon</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNPrintInfoDialog</name>
    <message>
        <location filename="../../../k1160/hnprintinfodialog.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnprintinfodialog.ui" line="26"/>
        <location filename="../../../k1160/hnprintinfodialog.ui" line="39"/>
        <source>PushButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../../k1160/hnprintinfodialog.ui" line="52"/>
        <source>海能仪器K1160全自动凯氏定氮仪实验报告</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../../k1160/hnprintinfodialog.ui" line="65"/>
        <source>济南海能仪器股份有限公司</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../../k1160/hnprintinfodialog.ui" line="78"/>
        <source>山东海能仪器股份有限公司</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNProgressBar</name>
    <message>
        <location filename="../../../k1160/HnGui/hnprogressbar.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNProgressDialog</name>
    <message>
        <location filename="../../../k1160/hnprogressdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnprogressdialog.ui" line="26"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnprogressdialog.ui" line="49"/>
        <source>Progressing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNPushButton</name>
    <message>
        <location filename="../../../k1160/HnGui/hnpushbutton.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNRadioButton</name>
    <message>
        <location filename="../../../k1160/HnGui/hnradiobutton.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNSampleDataWidget</name>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.ui" line="36"/>
        <source>left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.ui" line="49"/>
        <source>right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.ui" line="62"/>
        <source>print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.ui" line="75"/>
        <source>export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.ui" line="88"/>
        <source>delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="103"/>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="153"/>
        <source>No.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="104"/>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="154"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="105"/>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="155"/>
        <source>Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="106"/>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="156"/>
        <source>Dos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="107"/>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="157"/>
        <source>ML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="108"/>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="158"/>
        <source>Result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="109"/>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="159"/>
        <source>RML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="110"/>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="160"/>
        <source>Tester</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="111"/>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="161"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="124"/>
        <source>Refreshing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="344"/>
        <source>Insert Printer, please!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="353"/>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="389"/>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="432"/>
        <source>No selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="363"/>
        <source>Printing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="368"/>
        <source>Print success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="380"/>
        <source>Insert u disk, please!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="399"/>
        <source>Exporting...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="421"/>
        <source>Export success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="436"/>
        <source>Delete this %1 items?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="442"/>
        <source>Deleting...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnsampledatawidget.cpp" line="458"/>
        <source>Delete success</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNSelfCheckForm</name>
    <message>
        <location filename="../../../k1160/hnselfcheckform.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNTabWidget</name>
    <message>
        <location filename="../../../k1160/HnGui/hntabwidget.ui" line="14"/>
        <source>TabWidget</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNTabWidgetB</name>
    <message>
        <location filename="../../../k1160/HnGui/hntabwidgetb.ui" line="14"/>
        <source>TabWidget</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNTableWidget</name>
    <message>
        <location filename="../../../k1160/HnGui/hntablewidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNTreeView</name>
    <message>
        <location filename="../../../k1160/HnGui/hntreeview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNTreeWidget</name>
    <message>
        <location filename="../../../k1160/HnGui/hntreewidget.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNUpgradeWidget</name>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.ui" line="14"/>
        <source>HNUpgradeWidget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.ui" line="44"/>
        <source>System Upgrade:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.ui" line="70"/>
        <source>Wating...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="118"/>
        <source>Checking version...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="136"/>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="156"/>
        <source>Version:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="137"/>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="157"/>
        <source>Explain:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="138"/>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="158"/>
        <source>ReleaseStatus:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="139"/>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="159"/>
        <source>ReleaseDate:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="140"/>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="160"/>
        <source>FileMD5:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="141"/>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="161"/>
        <source>FileSize:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="146"/>
        <source>This is latest version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="154"/>
        <source>------------------------------------</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="155"/>
        <source>FileName:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="162"/>
        <source>Found new version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="168"/>
        <source>Downloading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="174"/>
        <source>Download success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="189"/>
        <source>Upgrade success, Restarting... %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNUserInfoView</name>
    <message>
        <location filename="../../../k1160/hnuserinfoview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNUserInfoWidget</name>
    <message>
        <location filename="../../../k1160/hnuserinfowidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnuserinfowidget.cpp" line="95"/>
        <source>DefaultLogin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnuserinfowidget.cpp" line="96"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnuserinfowidget.cpp" line="97"/>
        <source>Authority</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNWIFIView</name>
    <message>
        <location filename="../../../k1160/hnwifiview.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNWIFIWidget</name>
    <message>
        <location filename="../../../k1160/hnwifiwidget.ui" line="16"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/hnwifiwidget.cpp" line="54"/>
        <source>Password error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNWidget</name>
    <message>
        <location filename="../../../k1160/HnGui/hnwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNWindow</name>
    <message>
        <location filename="../../../k1160/hnwindow.ui" line="20"/>
        <source>StackedWidget</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HNWord</name>
    <message>
        <location filename="../../../k1160/HnGui/hnword.cpp" line="424"/>
        <source>ç¬¬ </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HnGui/hnword.cpp" line="424"/>
        <source> é¡µ</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAutoTest</name>
    <message>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="17"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="145"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="158"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="171"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="184"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="197"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="210"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="223"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="236"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="249"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="262"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="275"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="288"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="301"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="314"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="327"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="340"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="353"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="366"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="379"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="392"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="405"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="418"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="431"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="454"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="467"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="480"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="493"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="506"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="649"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="662"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="675"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="688"/>
        <location filename="../../../k1160/k1160pro/qautotest.ui" line="701"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAutoTestaProcessForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="26"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="39"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="52"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="65"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="78"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="91"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="104"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="117"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="130"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="143"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="156"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="169"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="182"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="195"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="208"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="247"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="260"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="273"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="286"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="315"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="328"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="341"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="354"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="367"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="380"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="393"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="406"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="419"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="432"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="445"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="458"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="471"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="484"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="497"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="510"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="523"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="536"/>
        <location filename="../../../k1160/k1160pro/qautotestaprocessform.ui" line="575"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBackupLocalThread</name>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="11"/>
        <source>Backuping...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="20"/>
        <source>Success</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QCleanForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qcleanform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qcleanform.ui" line="26"/>
        <location filename="../../../k1160/k1160pro/qcleanform.ui" line="39"/>
        <location filename="../../../k1160/k1160pro/qcleanform.ui" line="52"/>
        <location filename="../../../k1160/k1160pro/qcleanform.ui" line="65"/>
        <location filename="../../../k1160/k1160pro/qcleanform.ui" line="78"/>
        <location filename="../../../k1160/k1160pro/qcleanform.ui" line="91"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QHelpForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qhelpform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qhelpform.ui" line="26"/>
        <location filename="../../../k1160/k1160pro/qhelpform.ui" line="39"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QManualTestForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="195"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="208"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="221"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="234"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="247"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="260"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="273"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="286"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="299"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="312"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="325"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="338"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="351"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="364"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="377"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="390"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="403"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="416"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="429"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="442"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="455"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="468"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="637"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="650"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="663"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="676"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="689"/>
        <location filename="../../../k1160/k1160pro/qmanualtestform.ui" line="702"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../k1160/HnGui/HNDefine.cpp" line="183"/>
        <location filename="../../../k1160/HnGui/HNDefine.cpp" line="196"/>
        <source>QSQLITE %1 Error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPiciFrom</name>
    <message>
        <location filename="../../../k1160/k1160pro/qpicifrom.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qpicifrom.ui" line="151"/>
        <location filename="../../../k1160/k1160pro/qpicifrom.ui" line="164"/>
        <location filename="../../../k1160/k1160pro/qpicifrom.ui" line="177"/>
        <location filename="../../../k1160/k1160pro/qpicifrom.ui" line="190"/>
        <location filename="../../../k1160/k1160pro/qpicifrom.ui" line="203"/>
        <location filename="../../../k1160/k1160pro/qpicifrom.ui" line="216"/>
        <location filename="../../../k1160/k1160pro/qpicifrom.ui" line="229"/>
        <location filename="../../../k1160/k1160pro/qpicifrom.ui" line="242"/>
        <location filename="../../../k1160/k1160pro/qpicifrom.ui" line="278"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSettingCalibrationForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingcalibrationform.ui" line="17"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingcalibrationform.ui" line="29"/>
        <location filename="../../../k1160/k1160pro/qsettingcalibrationform.ui" line="42"/>
        <location filename="../../../k1160/k1160pro/qsettingcalibrationform.ui" line="55"/>
        <location filename="../../../k1160/k1160pro/qsettingcalibrationform.ui" line="68"/>
        <location filename="../../../k1160/k1160pro/qsettingcalibrationform.ui" line="81"/>
        <location filename="../../../k1160/k1160pro/qsettingcalibrationform.ui" line="94"/>
        <location filename="../../../k1160/k1160pro/qsettingcalibrationform.ui" line="211"/>
        <location filename="../../../k1160/k1160pro/qsettingcalibrationform.ui" line="280"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSettingCleanForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="26"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="39"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="52"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="65"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="78"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="91"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="167"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="180"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="193"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="206"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="219"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="232"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="245"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="258"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="271"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="284"/>
        <location filename="../../../k1160/k1160pro/qsettingcleanform.ui" line="297"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSettingDebugForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="52"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="65"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="78"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="91"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="104"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="117"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="130"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="143"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="156"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="169"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="182"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="195"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="208"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="221"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="234"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="247"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="260"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="273"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="286"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="299"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="312"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="351"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="364"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="377"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="390"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="403"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="416"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="429"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="442"/>
        <location filename="../../../k1160/k1160pro/qsettingdebugform.ui" line="455"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSettingMachineForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="26"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="39"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="52"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="65"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="78"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="91"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="310"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="323"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="336"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="349"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="362"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="375"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="229"/>
        <source>2015</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="245"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="258"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="271"/>
        <source>23</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="284"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="297"/>
        <source>59</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="388"/>
        <location filename="../../../k1160/k1160pro/qsettingmachineform.ui" line="401"/>
        <source>RadioButton</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSettingMethodForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="194"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="207"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="220"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="233"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="246"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="259"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="272"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="285"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="298"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="311"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="324"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="337"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="350"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="363"/>
        <location filename="../../../k1160/k1160pro/qsettingmethodform.ui" line="376"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSettingNetForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingnetform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingnetform.ui" line="66"/>
        <location filename="../../../k1160/k1160pro/qsettingnetform.ui" line="79"/>
        <location filename="../../../k1160/k1160pro/qsettingnetform.ui" line="92"/>
        <location filename="../../../k1160/k1160pro/qsettingnetform.ui" line="105"/>
        <location filename="../../../k1160/k1160pro/qsettingnetform.ui" line="144"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingnetform.cpp" line="122"/>
        <source>Current:Wired Lan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingnetform.cpp" line="127"/>
        <source>Current:%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSettingOriginsForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingoriginsform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingoriginsform.cpp" line="250"/>
        <location filename="../../../k1160/k1160pro/qsettingoriginsform.cpp" line="256"/>
        <location filename="../../../k1160/k1160pro/qsettingoriginsform.cpp" line="264"/>
        <source>æç¤º</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingoriginsform.cpp" line="250"/>
        <source>è¯·è¾å¥æ°å­</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingoriginsform.cpp" line="256"/>
        <source>è¯·è¾å¥è·³è½¬é¡µé¢</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettingoriginsform.cpp" line="264"/>
        <source>æ²¡ææå®çé¡µé¢ï¼è¯·éæ°è¾å¥</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSettingUserForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/qsettinguserform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettinguserform.ui" line="151"/>
        <location filename="../../../k1160/k1160pro/qsettinguserform.ui" line="164"/>
        <location filename="../../../k1160/k1160pro/qsettinguserform.ui" line="177"/>
        <location filename="../../../k1160/k1160pro/qsettinguserform.ui" line="190"/>
        <location filename="../../../k1160/k1160pro/qsettinguserform.ui" line="203"/>
        <location filename="../../../k1160/k1160pro/qsettinguserform.ui" line="216"/>
        <location filename="../../../k1160/k1160pro/qsettinguserform.ui" line="239"/>
        <location filename="../../../k1160/k1160pro/qsettinguserform.ui" line="275"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/qsettinguserform.ui" line="288"/>
        <source>CheckBox</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUpgradeThread</name>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="26"/>
        <source>Upgrading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/hnupgradewidget.cpp" line="36"/>
        <source>Success</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUserForm</name>
    <message>
        <location filename="../../../k1160/k1160pro/quserform.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/k1160pro/quserform.ui" line="82"/>
        <location filename="../../../k1160/k1160pro/quserform.ui" line="95"/>
        <location filename="../../../k1160/k1160pro/quserform.ui" line="108"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>frmInput</name>
    <message utf8="true">
        <location filename="../../../k1160/HNInput.ui" line="20"/>
        <source>中文输入法面板</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="325"/>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="350"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="493"/>
        <source>z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="509"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="525"/>
        <source>c</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="541"/>
        <source>v</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="557"/>
        <source>b</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="573"/>
        <source>n</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="589"/>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="605"/>
        <location filename="../../../k1160/HNInput.ui" line="1689"/>
        <source>,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="621"/>
        <location filename="../../../k1160/HNInput.ui" line="1705"/>
        <source>.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="637"/>
        <location filename="../../../k1160/HNInput.ui" line="1721"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="690"/>
        <source>a</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="706"/>
        <source>s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="722"/>
        <source>d</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="738"/>
        <source>f</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="754"/>
        <source>g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="770"/>
        <source>h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="786"/>
        <source>j</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="802"/>
        <source>k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="818"/>
        <source>l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="834"/>
        <source>?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="887"/>
        <source>q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="903"/>
        <source>w</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="919"/>
        <source>e</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="935"/>
        <source>r</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="951"/>
        <source>t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="967"/>
        <source>y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="983"/>
        <source>u</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="999"/>
        <source>i</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1015"/>
        <source>o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1031"/>
        <source>p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1119"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1135"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1151"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1167"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1183"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1199"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1215"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1231"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1247"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1263"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1348"/>
        <source>!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1364"/>
        <source>@</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1380"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1396"/>
        <source>$</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1412"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1428"/>
        <source>^</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1444"/>
        <source>&amp;&amp;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1460"/>
        <source>*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1476"/>
        <source>(</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1492"/>
        <source>)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1561"/>
        <source>\</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1577"/>
        <source>_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1593"/>
        <source>|</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1609"/>
        <source>/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1625"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1641"/>
        <source>&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1657"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1673"/>
        <source>=</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../../k1160/HNInput.ui" line="1784"/>
        <source>中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../../../k1160/HNInput.ui" line="1791"/>
        <source>英文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../k1160/HNInput.ui" line="1798"/>
        <source>123</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
