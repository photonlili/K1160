#!/bin/sh
ps -o pid,comm | grep -i $1

